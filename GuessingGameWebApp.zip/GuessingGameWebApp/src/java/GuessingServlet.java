import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.jstl.core.Config;

public class GuessingServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String userOpt = request.getParameter("game_opt");
        String userName = request.getParameter("name");
        
        String[] options = {"tail","head"};
        Random randomizer = new Random();
        
        int index = randomizer.nextInt(2); // 0-1
        // num = min + random.nextInt(max-min + 1)
        
//        Alternative
//        switch (index) {
//            case 0: compOpt = "tail"; break;
//            case 1: compOpt = "head"; break;
//        }     

        String computerOpt = options[index];
        String results;
        
        if(userOpt.equals(computerOpt))
            results = userName + " has won!";
        else
            results = "Siri" + " has won!";
        
        request.setAttribute("userOpt", userOpt);
        request.setAttribute("computerOpt", computerOpt);
        request.setAttribute("results", results);
        request.setAttribute("user", userName);
 
        request.getRequestDispatcher("view_results.jsp").forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
